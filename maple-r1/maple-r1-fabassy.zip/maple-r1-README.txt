GERBERS
maple-r1.bot	Bottom Copper
maple-r1.drd	NC Drill
maple-r1.smb	Bottom Soldermask
maple-r1.smt	Top Soldermask
maple-r1.ssb	Bottom Silkscreen
maple-r1.sst	Top Silkscreen
maple-r1.top	Top Copper

