GERBERS
maple-r3.bot	Bottom Copper
maple-r3.bsm	Bottom Silkscreen
maple-r3.bss	Bottom Silkscreen
maple-r3.drd	NC Drill
maple-r3.gnd	Inner Layer 2: GND
maple-r3.sup	Inner Layer 3: SUPPLY
maple-r3.top	Top Copper
maple-r3.tsm	Top Soldermask
maple-r3.tss	Top Silkscreen

EAGLE FILES
maple-r3.sch
maple-r3.brd

Soldermark Color: Dark Red
Silkscreen Color: White
