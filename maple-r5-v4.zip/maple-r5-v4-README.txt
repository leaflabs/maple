GERBERS
maple-r5-v4.bot	Bottom Copper
maple-r5-v4.bsm	Bottom Silkscreen
maple-r5-v4.bss	Bottom Silkscreen
maple-r5-v4.drd	NC Drill
maple-r5-v4.gnd	Inner Layer 2: GND
maple-r5-v4.sup	Inner Layer 3: SUPPLY
maple-r5-v4.top	Top Copper
maple-r5-v4.tsm	Top Soldermask
maple-r5-v4.tss	Top Silkscreen

EAGLE FILES
maple-r5-v4.sch
maple-r5-v4.brd

Soldermark Color: Dark Red
SilkScreen Color: White

