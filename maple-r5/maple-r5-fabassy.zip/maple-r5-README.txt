GERBERS
maple-r5.bot	Bottom Copper
maple-r5.bsm	Bottom Silkscreen
maple-r5.bss	Bottom Silkscreen
maple-r5.drd	NC Drill
maple-r5.gnd	Inner Layer 2: GND
maple-r5.sup	Inner Layer 3: SUPPLY
maple-r5.top	Top Copper
maple-r5.tsm	Top Soldermask
maple-r5.tss	Top Silkscreen

EAGLE FILES
maple-r5.sch
maple-r5.brd

Soldermark Color: Dark Red
Silkscreen Color: White

